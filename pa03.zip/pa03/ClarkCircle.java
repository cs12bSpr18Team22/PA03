package pa03;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Timer;


public class ClarkCircle extends CircleShape{

  public ClarkCircle(){
    super();
		this.color = new java.awt.Color(0,0,255,100);
  }
          public void draw( Graphics g ) {
              int u = (int)(x-radius);
              int v = (int)(y-radius);
              int w = (int)(2*radius);
              int h = w;
              g.setColor(Color.blue);
              g.fillOval( u,v,w,h );
              g.setColor(Color.green);
              g.drawOval( u,v,w,h );
          }
        }
