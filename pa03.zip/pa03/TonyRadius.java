package pa03;

import java.util.Timer;

public class TonyRadius extends CircleShape{

  public TonyRadius(){
    super();
    this.radius = 60;
  }

  public class CountTime{
    Timer timer = new Timer();
  }

}
