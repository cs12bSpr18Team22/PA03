package pa03;

import java.awt.Color;

public class EmmaColor extends CircleShape{

  public EmmaColor(){
    super();
    this.color = new Color(0,255,0,100);
  }

}
